// Configuration
const API_BASE = '' // e.g. 'https://your-api-host.example' — leave blank to use local fallback
const API_USERNAME = 'coalition'
const API_PASSWORD = 'skills-test'

async function fetchPatients(){
  if(!API_BASE) return null
  const url = `${API_BASE.replace(/\/$/, '')}/patients`
  const headers = new Headers()
  headers.set('Authorization','Basic ' + btoa(`${API_USERNAME}:${API_PASSWORD}`))

  try{
    const res = await fetch(url,{headers})
    if(!res.ok) throw new Error('Network response not ok')
    const data = await res.json()
    return Array.isArray(data) ? data : (data.patients || null)
  }catch(e){
    console.warn('API fetch failed, falling back to sample data',e)
    return null
  }
}

// Minimal sample data for Jessica Taylor if API is unavailable
const samplePatients = [
  {
    id: 'JT-0001',
    firstName: 'Jessica',
    lastName: 'Taylor',
    dob: '1986-07-18',
    gender: 'Female',
    phone: '(415) 555-1234',
    emergencyContact: '(415) 555-5678',
    insuranceProvider: 'Sunrise Health Insurance',
    bloodPressure: {
      systolic: 160,
      diastolic: 78
    },
    respiratoryRate: 20,
    temperature: 98.6,
    heartRate: 78,
    bpRecords: [
      {year:2018, systolic:122, diastolic:80},
      {year:2019, systolic:125, diastolic:82},
      {year:2020, systolic:130, diastolic:85},
      {year:2021, systolic:128, diastolic:83},
      {year:2022, systolic:135, diastolic:87},
      {year:2023, systolic:132, diastolic:86}
    ]
  }
]

// Sample list of all patients
const allSamplePatients = [
  {firstName: 'Emily', lastName: 'Williams', gender: 'Female', age: 18},
  {firstName: 'Ryan', lastName: 'Johnson', gender: 'Male', age: 45},
  {firstName: 'Brandon', lastName: 'Mitchell', gender: 'Male', age: 36},
  {firstName: 'Jessica', lastName: 'Taylor', gender: 'Female', age: 28},
  {firstName: 'Samantha', lastName: 'Johnson', gender: 'Female', age: 56},
  {firstName: 'Ashley', lastName: 'Martinez', gender: 'Female', age: 54},
  {firstName: 'Olivia', lastName: 'Brown', gender: 'Female', age: 32},
  {firstName: 'Tyler', lastName: 'Davis', gender: 'Male', age: 41},
  {firstName: 'Kevin', lastName: 'Anderson', gender: 'Male', age: 50},
  {firstName: 'Dylan', lastName: 'Thompson', gender: 'Male', age: 36},
  {firstName: 'Nathan', lastName: 'Evans', gender: 'Male', age: 58},
  {firstName: 'Mike', lastName: 'Nolan', gender: 'Male', age: 31}
]

function getInitials(firstName, lastName){
  return ((firstName||'')[0] + (lastName||'')[0]).toUpperCase()
}

function findJessica(patients){
  if(!patients) return null
  return patients.find(p=>{
    const full = `${(p.firstName||p.name||'').toString()} ${(p.lastName||'').toString()}`.toLowerCase()
    return full.includes('jessica taylor') || (p.firstName && p.firstName.toLowerCase()==='jessica' && (p.lastName||'').toLowerCase()==='taylor')
  }) || null
}

function renderPatientList(patients){
  const list = document.getElementById('patientsList')
  list.innerHTML = ''
  
  const patientsToShow = patients || allSamplePatients
  patientsToShow.forEach(p=>{
    const item = document.createElement('div')
    item.className = 'patient-item'
    
    // Check if this is Jessica Taylor
    const isJessica = p.firstName && p.firstName.toLowerCase()==='jessica' && (p.lastName||'').toLowerCase()==='taylor'
    if(isJessica) item.classList.add('active')
    
    const initials = getInitials(p.firstName, p.lastName)
    
    item.innerHTML = `
      <div class="patient-avatar">${initials}</div>
      <div class="patient-item-details">
        <div class="patient-item-name">${p.firstName || p.name || ''} ${p.lastName || ''}</div>
        <div class="patient-item-meta">${p.gender || ''}, ${p.age || ''}</div>
      </div>
      <div class="patient-menu">⋯</div>
    `
    list.appendChild(item)
  })
}

function renderPatient(p){
  if(!p) return
  const name = `${p.firstName || p.name || ''} ${p.lastName || ''}`.trim() || 'Jessica Taylor'
  document.getElementById('patientNameHeader').textContent = name
  document.getElementById('patientMetaHeader').textContent = p.dob ? `DOB: ${p.dob}` : ''
  document.getElementById('patientDOB').textContent = p.dob ? formatDate(p.dob) : '—'
  document.getElementById('patientGenderDetail').textContent = p.gender || '—'
  document.getElementById('patientPhone').textContent = p.phone || '—'
  document.getElementById('patientEmergency').textContent = p.emergencyContact || '—'
  document.getElementById('patientInsurance').textContent = p.insuranceProvider || '—'
  
  // Current vitals
  if(p.bloodPressure){
    document.getElementById('systolicValue').textContent = p.bloodPressure.systolic || '—'
    document.getElementById('diastolicValue').textContent = p.bloodPressure.diastolic || '—'
  }
  document.getElementById('respiratoryRate').textContent = p.respiratoryRate || '—'
  document.getElementById('temperatureValue').textContent = p.temperature || '—'
  document.getElementById('heartRateValue').textContent = p.heartRate || '—'
}

function formatDate(dob){
  try{
    const d = new Date(dob)
    return d.toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})
  }catch(e){return dob}
}

function bpRecordsFromPatient(p){
  // Try multiple possible fields
  if(!p) return []
  if(p.bpRecords && Array.isArray(p.bpRecords)) return p.bpRecords
  if(p.vitals && p.vitals.bloodPressure) return p.vitals.bloodPressure
  if(p.observations) return p.observations.filter(o=>o.type && o.type.toLowerCase().includes('blood')).map(o=>({year:o.year||o.date?.slice(0,4), systolic:o.systolic||o.sbp, diastolic:o.diastolic||o.dbp}))
  return []
}

function renderChart(records){
  const ctx = document.getElementById('bpChart').getContext('2d')
  const sorted = records.slice().sort((a,b)=>a.year - b.year)
  const labels = sorted.map(r=>r.year)
  const syst = sorted.map(r=>r.systolic)
  const diast = sorted.map(r=>r.diastolic)

  new Chart(ctx,{
    type:'line',
    data:{
      labels,
      datasets:[
        {
          label:'Systolic',
          data:syst,
          borderColor:'#EF4444',
          backgroundColor:'rgba(239,68,68,0.08)',
          tension:0.4,
          pointRadius:5,
          pointBackgroundColor:'#EF4444',
          borderWidth:2
        },
        {
          label:'Diastolic',
          data:diast,
          borderColor:'#007BC7',
          backgroundColor:'rgba(0,123,199,0.08)',
          tension:0.4,
          pointRadius:5,
          pointBackgroundColor:'#007BC7',
          borderWidth:2
        }
      ]
    },
    options:{
      responsive:true,
      maintainAspectRatio:false,
      plugins:{
        legend:{
          display:false
        }
      },
      scales:{
        y:{
          beginAtZero:true,
          max:200,
          ticks:{color:'#878787'}
        },
        x:{
          ticks:{color:'#878787'}
        }
      }
    }
  })
}

async function init(){
  // Render patient list
  renderPatientList(allSamplePatients)
  
  // Fetch and display Jessica Taylor
  const patients = await fetchPatients()
  const source = patients || samplePatients
  const j = findJessica(source)
  const patient = j || samplePatients[0]
  
  renderPatient(patient)
  
  const records = bpRecordsFromPatient(patient)
  renderChart((records && records.length>0) ? records : patient.bpRecords || samplePatients[0].bpRecords)
}

init()


